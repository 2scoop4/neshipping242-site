(function(){
  const form = document.getElementById('loginForm');
  const emailEl = document.getElementById('email');
  const passEl = document.getElementById('password');
  const errBox = document.getElementById('errBox');
  const forgot = document.getElementById('forgotLink');
  const btn = document.getElementById('loginBtn');

  function showErr(msg){
    errBox.style.display = 'block';
    errBox.textContent = msg;
  }
  function clearErr(){
    errBox.style.display = 'none';
    errBox.textContent = '';
  }

  function redirectToApp(){
    // Use /employee/app.html for dashboard
    window.location.href = '/employee/app.html';
  }

  // If already logged in, go straight to app
  function boot(){
    if (!window.netlifyIdentity){
      showErr('Login system failed to load. Please refresh and try again.');
      return;
    }
    window.netlifyIdentity.on('init', user => {
      if (user) redirectToApp();
    });
    window.netlifyIdentity.init();
  }

  forgot.addEventListener('click', async (e) => {
    e.preventDefault();
    clearErr();
    const email = (emailEl.value || '').trim();
    if (!email){
      showErr('Enter your email first, then click “Forgot password?”.');
      return;
    }
    try{
      btn.disabled = true;
      // gotrue-js requestPasswordRecovery
      const gt = window.netlifyIdentity && window.netlifyIdentity.gotrue;
      if (!gt || !gt.requestPasswordRecovery) throw new Error('Password recovery is unavailable.');
      await gt.requestPasswordRecovery(email);
      showErr('Password reset email sent. Check your inbox.');
      errBox.style.background = '#ecfdf5';
      errBox.style.borderColor = '#a7f3d0';
      errBox.style.color = '#065f46';
    }catch(err){
      showErr(err?.message || 'Could not send reset email.');
    }finally{
      btn.disabled = false;
    }
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErr();
    const email = (emailEl.value || '').trim();
    const password = passEl.value || '';
    if (!email || !password){
      showErr('Please enter your email and password.');
      return;
    }
    try{
      btn.disabled = true;
      const gt = window.netlifyIdentity && window.netlifyIdentity.gotrue;
      if (!gt || !gt.login) throw new Error('Login system is unavailable. Try refreshing.');
      await gt.login(email, password, true);
      redirectToApp();
    }catch(err){
      showErr(err?.message || 'Login failed.');
    }finally{
      btn.disabled = false;
    }
  });

  boot();
})();