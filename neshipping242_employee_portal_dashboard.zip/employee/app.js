(function(){
  const $ = (id)=>document.getElementById(id);
  const modal = $('modal');
  const addBtn = $('addBtn');
  const refreshBtn = $('refreshBtn');
  const logoutLink = $('logoutLink');
  const whoPill = $('whoPill');
  const helloText = $('helloText');
  const searchBox = $('searchBox');
  const filterIsland = $('filterIsland');
  const filterStatus = $('filterStatus');
  const form = $('pkgForm');
  const formError = $('formError');
  const modalTitle = $('modalTitle');
  const saveBtn = $('saveBtn');

  // form fields
  const fTracking = $('fTracking');
  const fCustomer = $('fCustomer');
  const fIsland = $('fIsland');
  const fCarrier = $('fCarrier');
  const fType = $('fType');
  const fWeight = $('fWeight');
  const fStatus = $('fStatus');
  const fSupplier = $('fSupplier');
  const fDesc = $('fDesc');
  const fPhoto = $('fPhoto');

  let currentUser = null;
  let isAdmin = false;
  let table = null;
  let editingRecordId = null;

  function openModal(title){
    modalTitle.textContent = title;
    modal.setAttribute('aria-hidden','false');
  }
  function closeModal(){
    modal.setAttribute('aria-hidden','true');
    form.reset();
    editingRecordId = null;
    formError.classList.remove('show');
    formError.textContent = '';
  }

  // Close modal clicks
  modal.addEventListener('click', (e)=>{
    const close = e.target && e.target.getAttribute('data-close');
    if (close) closeModal();
  });

  function showFormError(msg){
    formError.textContent = msg;
    formError.classList.add('show');
  }

  async function toBase64(file){
    return new Promise((resolve,reject)=>{
      const r = new FileReader();
      r.onload = ()=> {
        const result = String(r.result || '');
        // result is data:<mime>;base64,XXXX
        const idx = result.indexOf('base64,');
        resolve(idx >= 0 ? result.slice(idx + 7) : result);
      };
      r.onerror = ()=>reject(r.error || new Error('read error'));
      r.readAsDataURL(file);
    });
  }

  async function authedFetch(url, options={}){
    const u = currentUser;
    if (!u) throw new Error('Not logged in');
    const token = await u.jwt();
    const headers = Object.assign({}, options.headers || {}, { Authorization: `Bearer ${token}` });
    return fetch(url, Object.assign({}, options, { headers }));
  }

  function fmtDate(iso){
    if (!iso) return '';
    try{
      const d = new Date(iso);
      if (Number.isNaN(d.getTime())) return iso;
      return d.toLocaleDateString();
    }catch{ return iso; }
  }

    function escapeHtml(str){
    return String(str ?? '').replace(/[&<>"']/g, (m)=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]));
  }

function photoThumb(cell){
    const v = cell.getValue();
    if (!v || !Array.isArray(v) || !v.length) return '';
    const url = v[0].thumbnails?.small?.url || v[0].url;
    if (!url) return '';
    return `<img src="${url}" style="width:36px;height:36px;object-fit:cover;border-radius:8px;border:1px solid #e5e7eb" />`;
  }

  function buildGrid(records){
    const rows = records.map(r=>{
      const f = r.fields || {};
      return {
        _id: r.id,
        receipt: f['Receipt #'] || '',
        tracking: f['Tracking Number'] || '',
        customer: f['Customer Name'] || '',
        island: f['Island'] || '',
        carrier: f['Carrier'] || '',
        type: f['Package Type'] || '',
        weight: f['Weight (lb)'] ?? '',
        status: f['Status'] || 'Received',
        receivedAt: f['Received At'] || '',
        receivedBy: f['Received By'] || '',
        supplier: f['Supplier'] || '',
        desc: f['Item Description'] || '',
        photo: f['Package Photo'] || [],
      };
    });

    if (!table){
      table = new Tabulator('#grid', {
        data: rows,
        layout: 'fitColumns',
        height: 'calc(100vh - 220px)',
        placeholder: 'No packages yet.',
        selectable: 1,
        rowClick: function(e, row){
          // Toggle details when clicking the expand column or anywhere on the row
          const el = row.getElement();
          const detail = el.querySelector('.rowDetail');
          if (!detail) return;
          const isOpen = detail.getAttribute('data-open') === '1';
          detail.setAttribute('data-open', isOpen ? '0' : '1');
          detail.style.display = isOpen ? 'none' : 'block';
        },
        rowFormatter: function(row){
          const data = row.getData();
          const el = row.getElement();

          // Remove any existing detail to avoid duplicates
          const old = el.querySelector('.rowDetail');
          if (old) old.remove();

          const detail = document.createElement('div');
          detail.className = 'rowDetail';
          detail.setAttribute('data-open','0');
          detail.style.display = 'none';
          detail.style.padding = '12px 14px';
          detail.style.borderTop = '1px solid #e5e7eb';
          detail.style.background = '#f9fafb';

          const photo = (data.photo && Array.isArray(data.photo) && data.photo.length) ? (data.photo[0].url || '') : '';
          const photoHtml = photo ? `<img src="${photo}" style="width:180px;height:180px;object-fit:cover;border-radius:12px;border:1px solid #e5e7eb" />` : `<div style="width:180px;height:180px;display:grid;place-items:center;border-radius:12px;border:1px dashed #d1d5db;color:#6b7280">No photo</div>`;

          detail.innerHTML = `
            <div style="display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap">
              <div>${photoHtml}</div>
              <div style="min-width:260px;flex:1">
                <div style="font-weight:900;margin-bottom:6px">${escapeHtml(data.tracking || '')}</div>
                <div style="color:#6b7280;font-size:13px;margin-bottom:10px">Received by <b>${escapeHtml(data.receivedBy || '')}</b> • ${escapeHtml(fmtDate(data.receivedAt) || '')}</div>
                <div style="display:grid;grid-template-columns: 160px 1fr;gap:6px 10px;font-size:13px">
                  <div style="color:#6b7280">Customer</div><div>${escapeHtml(data.customer || '')}</div>
                  <div style="color:#6b7280">Island</div><div>${escapeHtml(data.island || '')}</div>
                  <div style="color:#6b7280">Carrier</div><div>${escapeHtml(data.carrier || '')}</div>
                  <div style="color:#6b7280">Package Type</div><div>${escapeHtml(data.type || '')}</div>
                  <div style="color:#6b7280">Supplier</div><div>${escapeHtml(data.supplier || '')}</div>
                  <div style="color:#6b7280">Description</div><div>${escapeHtml(data.desc || '')}</div>
                </div>
              </div>
            </div>
          `;
          el.appendChild(detail);
        },
columns: [
          {title:'', field:'_expand', width:46, hozAlign:'center', headerSort:false, formatter:()=>'<span style="font-weight:900">+</span>'},
          {title:'Tracking #', field:'tracking', minWidth:170},
          {title:'Customer', field:'customer', minWidth:160, editor:'input'},
          {title:'Island', field:'island', width:110, editor:'select', editorParams:{values:['Abaco','Freeport','Nassau','Bimini']}},
          {title:'Weight', field:'weight', width:90, hozAlign:'right', editor:'number'},
          {title:'Status', field:'status', width:110, editor:'select', editorParams:{values:['Received','Ready','Shipped','Delivered','On Hold']}},
          {title:'Received', field:'receivedAt', width:120, formatter:(c)=>fmtDate(c.getValue())},
          {title:'Photo', field:'photo', width:80, hozAlign:'center', formatter:photoThumb, headerSort:false},
          {title:'', field:'_actions', width:120, headerSort:false, formatter:(cell)=>{
            const id = cell.getRow().getData()._id;
            const delBtn = isAdmin ? `<button class="iconBtn" data-del="${id}" title="Delete">🗑</button>` : '';
            return `<div style="display:flex;gap:8px;justify-content:flex-end">
              <button class="iconBtn" data-edit="${id}" title="Edit">✎</button>
              ${delBtn}
            </div>`;
          }},
        ],
        cellEdited: async function(cell){
          // Auto-save on edit
          const row = cell.getRow().getData();
          try{
            await updateRecord(row._id, {
              'Customer Name': row.customer,
              'Island': row.island,
              'Weight (lb)': row.weight,
              'Status': row.status,
            });
          }catch(err){
            alert(err?.message || 'Update failed');
          }
        },
      });

      // action buttons
      document.getElementById('grid').addEventListener('click', async (e)=>{
        const editId = e.target?.getAttribute?.('data-edit');
        const delId = e.target?.getAttribute?.('data-del');
        if (editId){
          const row = table.getData().find(r=>r._id===editId);
          if (!row) return;
          editingRecordId = editId;
          modalTitle.textContent = 'Edit Package';
          fTracking.value = row.tracking;
          fCustomer.value = row.customer;
          fIsland.value = row.island || '';
          fCarrier.value = row.carrier;
          fType.value = row.type;
          fWeight.value = row.weight;
          fStatus.value = row.status || 'Received';
          fSupplier.value = row.supplier;
          fDesc.value = row.desc;
          openModal('Edit Package');
        }
        if (delId){
          if (!isAdmin) return;
          if (!confirm('Delete this package record?')) return;
          try{
            await deleteRecord(delId);
            await load();
          }catch(err){
            alert(err?.message || 'Delete failed');
          }
        }
      });

    }else{
      table.replaceData(rows);
    }
  }

  async function load(){
    const res = await authedFetch('/.netlify/functions/getPackages');
    const data = await res.json().catch(()=>({}));
    if (!res.ok) throw new Error(data?.error || 'Failed to load packages');
    isAdmin = !!data.isAdmin;
    buildGrid(data.records || []);
  }

  async function createRecord(payload){
    const res = await authedFetch('/.netlify/functions/submitPackage', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(()=>({}));
    if (!res.ok || !data.ok) throw new Error(data?.error || 'Create failed');
    return data;
  }

  async function updateRecord(recordId, fields, photo=null){
    const body = { recordId, fields };
    if (photo) body.photo = photo;
    const res = await authedFetch('/.netlify/functions/updatePackage', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(()=>({}));
    if (!res.ok || !data.ok) throw new Error(data?.error || 'Update failed');
    return data;
  }

  async function deleteRecord(recordId){
    const res = await authedFetch('/.netlify/functions/deletePackage', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ recordId }),
    });
    const data = await res.json().catch(()=>({}));
    if (!res.ok || !data.ok) throw new Error(data?.error || 'Delete failed');
    return data;
  }

  // Toolbar filter chips
  document.querySelectorAll('.chip[data-range]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      document.querySelectorAll('.chip[data-range]').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      const range = btn.getAttribute('data-range');
      if (!table) return;
      table.clearFilter(true);

      // apply select filters after date range
      applyFilters(range);
    });
  });

  function applyFilters(range){
    if (!table) return;
    const island = filterIsland.value || '';
    const status = filterStatus.value || '';
    const q = (searchBox.value || '').trim().toLowerCase();

    table.setFilter((data)=>{
      // date range
      if (range && range !== 'all'){
        const days = Number(range);
        const dt = data.receivedAt ? new Date(data.receivedAt) : null;
        if (dt && Number.isFinite(dt.getTime())){
          const cutoff = Date.now() - days*24*60*60*1000;
          if (dt.getTime() < cutoff) return false;
        }
      }
      if (island && data.island !== island) return false;
      if (status && data.status !== status) return false;
      if (q){
        const hay = `${data.tracking} ${data.customer} ${data.supplier} ${data.carrier} ${data.island} ${data.status}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }

  function currentRange(){
    const active = document.querySelector('.chip.active[data-range]');
    return active ? active.getAttribute('data-range') : 'all';
  }

  [filterIsland, filterStatus, searchBox].forEach(el=>{
    el.addEventListener('input', ()=>applyFilters(currentRange()));
    el.addEventListener('change', ()=>applyFilters(currentRange()));
  });

  refreshBtn.addEventListener('click', async ()=>{
    try{
      refreshBtn.disabled = true;
      await load();
      applyFilters(currentRange());
    }catch(err){
      alert(err?.message || 'Refresh failed');
    }finally{
      refreshBtn.disabled = false;
    }
  });

  addBtn.addEventListener('click', ()=>{
    editingRecordId = null;
    form.reset();
    fStatus.value = 'Received';
    openModal('Add Package');
  });

  logoutLink.addEventListener('click', (e)=>{
    e.preventDefault();
    if (window.netlifyIdentity){
      window.netlifyIdentity.logout();
    }
    window.location.href = '/employee/';
  });

  // Submit modal form
  form.addEventListener('submit', async (e)=>{
    e.preventDefault();
    formError.classList.remove('show');
    formError.textContent = '';
    saveBtn.disabled = true;

    try{
      const payload = {
        trackingNumber: fTracking.value.trim(),
        customerName: fCustomer.value.trim(),
        island: fIsland.value,
        carrier: fCarrier.value.trim(),
        packageType: fType.value,
        weight: fWeight.value,
        supplier: fSupplier.value.trim(),
        itemDescription: fDesc.value.trim(),
        status: fStatus.value,
      };

      const file = fPhoto.files && fPhoto.files[0] ? fPhoto.files[0] : null;
      if (file){
        const b64 = await toBase64(file);
        payload.photo = {
          base64: b64,
          filename: file.name || 'photo.jpg',
          contentType: file.type || 'image/jpeg',
        };
      }

      if (editingRecordId){
        const fields = {
          'Tracking Number': payload.trackingNumber,
          'Customer Name': payload.customerName,
          'Island': payload.island,
          'Carrier': payload.carrier,
          'Package Type': payload.packageType,
          'Weight (lb)': payload.weight,
          'Supplier': payload.supplier,
          'Item Description': payload.itemDescription,
          'Status': payload.status,
        };
        await updateRecord(editingRecordId, fields, payload.photo || null);
      }else{
        await createRecord(payload);
      }

      closeModal();
      await load();
      applyFilters(currentRange());
    }catch(err){
      showFormError(err?.message || 'Save failed');
    }finally{
      saveBtn.disabled = false;
    }
  });

  function boot(){
    if (!window.netlifyIdentity){
      alert('Login system failed to load. Refresh the page.');
      return;
    }

    window.netlifyIdentity.on('init', async (user)=>{
      if (!user){
        window.location.href = '/employee/';
        return;
      }
      currentUser = user;
      whoPill.textContent = user.email || 'Employee';
      helloText.textContent = 'Hello,';
      try{
        await load();
        applyFilters('all');
      }catch(err){
        alert(err?.message || 'Failed to load portal');
      }
    });

    window.netlifyIdentity.on('logout', ()=>{
      window.location.href = '/employee/';
    });

    window.netlifyIdentity.init();
  }

  boot();
})();