// Netlify Function: Delete a package record in Airtable (ADMIN ONLY; requires Netlify Identity auth)
function isAdminUser(user){
  const env = process.env.ADMIN_EMAILS || "";
  const list = env.split(",").map(s=>s.trim().toLowerCase()).filter(Boolean);
  const email = (user && user.email ? String(user.email).toLowerCase() : "");
  return !!email && list.includes(email);
}

export async function handler(event, context) {
  try {
    if (event.httpMethod !== "POST") {
      return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
    }

    const user = context.clientContext && context.clientContext.user;
    if (!user) {
      return { statusCode: 401, body: JSON.stringify({ error: "Unauthorized" }) };
    }

    if (!isAdminUser(user)) {
      return { statusCode: 403, body: JSON.stringify({ error: "Forbidden (admin only)" }) };
    }

    const { AIRTABLE_API_KEY, AIRTABLE_BASE_ID, AIRTABLE_TABLE_NAME } = process.env;
    if (!AIRTABLE_API_KEY || !AIRTABLE_BASE_ID || !AIRTABLE_TABLE_NAME) {
      return { statusCode: 500, body: JSON.stringify({ error: "Server not configured (missing Airtable env vars)." }) };
    }

    let payload;
    try {
      payload = JSON.parse(event.body || "{}");
    } catch {
      return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON." }) };
    }

    const recordId = String(payload.recordId || "").trim();
    if (!recordId) {
      return { statusCode: 400, body: JSON.stringify({ error: "Missing recordId" }) };
    }

    const url = `https://api.airtable.com/v0/${encodeURIComponent(AIRTABLE_BASE_ID)}/${encodeURIComponent(AIRTABLE_TABLE_NAME)}/${encodeURIComponent(recordId)}`;
    const res = await fetch(url, {
      method: "DELETE",
      headers: { "Authorization": `Bearer ${AIRTABLE_API_KEY}` },
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      return { statusCode: 502, body: JSON.stringify({ error: "Airtable error", details: data }) };
    }

    return { statusCode: 200, body: JSON.stringify({ ok: true, deleted: true }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: "Server error", message: err?.message || String(err) }) };
  }
}
