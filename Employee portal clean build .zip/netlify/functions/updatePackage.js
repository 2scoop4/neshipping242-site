
const { json, requireUser, airtableConfig, airtableFetch, uploadAttachment } = require("./_common");

exports.handler = async (event, context) => {
  try{
    const u = requireUser(context);
    const body = JSON.parse(event.body || "{}");
    const id = body.id;
    const fields = body.fields || {};
    const photo = body.photo || null;
    if(!id) return json(400, { error: "Missing record id" });

    const { baseId, tableName, photoField } = airtableConfig();

    // do not allow overwriting audit fields
    delete fields["Received At"];
    delete fields["Received By"];

    const updRes = await airtableFetch(`/${baseId}/${encodeURIComponent(tableName)}`, {
      method:"PATCH",
      headers: { "Content-Type":"application/json" },
      body: JSON.stringify({ records: [{ id, fields }] })
    });
    const updData = await updRes.json();
    if(!updRes.ok){
      return json(updRes.status, { error: updData?.error?.message || "Airtable update failed" });
    }
    if(photo){
      await uploadAttachment(id, photoField, photo);
    }
    return json(200, { ok:true });
  }catch(err){
    return json(err.statusCode || 500, { error: err.message || "Server error" });
  }
};
