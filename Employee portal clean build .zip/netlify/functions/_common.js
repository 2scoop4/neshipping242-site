
function json(statusCode, body){
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  };
}

function requireUser(context){
  const u = context?.clientContext?.user;
  if(!u) throw Object.assign(new Error("Unauthorized"), { statusCode: 401 });
  return u;
}

function isAdminEmail(email){
  const raw = process.env.ADMIN_EMAILS || "";
  const list = raw.split(",").map(s=>s.trim().toLowerCase()).filter(Boolean);
  return list.includes(String(email||"").toLowerCase());
}

function airtableConfig(){
  const apiKey = process.env.AIRTABLE_API_KEY;
  const baseId = process.env.AIRTABLE_BASE_ID;
  const tableName = process.env.AIRTABLE_TABLE_NAME || "Intake";
  const photoField = process.env.AIRTABLE_PHOTO_FIELD || "Package Photo";
  if(!apiKey || !baseId) throw Object.assign(new Error("Server missing Airtable env vars"), { statusCode: 500 });
  return { apiKey, baseId, tableName, photoField };
}

async function airtableFetch(path, init){
  const { apiKey } = airtableConfig();
  const headers = Object.assign({}, init?.headers || {});
  headers["Authorization"] = `Bearer ${apiKey}`;
  return await fetch(`https://api.airtable.com/v0${path}`, { ...init, headers });
}

function clampRecords(records, limit=50){
  return (records || []).slice(0, limit);
}

async function uploadAttachment(recordId, fieldName, photo){
  // photo: { dataUrl, filename, contentType }
  if(!photo?.dataUrl) return null;
  const { baseId, tableName, apiKey } = airtableConfig();

  const m = String(photo.dataUrl).match(/^data:(.+?);base64,(.+)$/);
  if(!m) throw new Error("Invalid photo encoding");
  const contentType = m[1];
  const base64Data = m[2];

  // Airtable Upload Attachment endpoint
  // POST https://api.airtable.com/v0/{baseId}/{tableId or tableName}/{recordId}/{fieldName}/uploadAttachment
  const url = `https://content.airtable.com/v0/${baseId}/${encodeURIComponent(tableName)}/${recordId}/${encodeURIComponent(fieldName)}/uploadAttachment`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      contentType: photo.contentType || contentType || "image/jpeg",
      file: base64Data,
      filename: photo.filename || "photo.jpg"
    })
  });
  if(!res.ok){
    const txt = await res.text();
    throw new Error(`Photo upload failed (${res.status}): ${txt}`);
  }
  return await res.json();
}

module.exports = { json, requireUser, isAdminEmail, airtableConfig, airtableFetch, clampRecords, uploadAttachment };
