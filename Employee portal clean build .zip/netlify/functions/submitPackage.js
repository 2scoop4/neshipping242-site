
const { json, requireUser, isAdminEmail, airtableConfig, airtableFetch, uploadAttachment } = require("./_common");

exports.handler = async (event, context) => {
  try{
    const u = requireUser(context);
    const body = JSON.parse(event.body || "{}");
    const fields = body.fields || {};
    const photo = body.photo || null;

    const { baseId, tableName, photoField } = airtableConfig();

    // enforce audit fields
    fields["Received At"] = new Date().toISOString();
    fields["Received By"] = u.email;

    const createRes = await airtableFetch(`/${baseId}/${encodeURIComponent(tableName)}`, {
      method:"POST",
      headers: { "Content-Type":"application/json" },
      body: JSON.stringify({ records: [{ fields }] })
    });
    const createData = await createRes.json();
    if(!createRes.ok){
      return json(createRes.status, { error: createData?.error?.message || "Airtable create failed" });
    }
    const recordId = createData.records?.[0]?.id;
    if(photo && recordId){
      await uploadAttachment(recordId, photoField, photo);
    }
    return json(200, { ok:true, id: recordId });
  }catch(err){
    return json(err.statusCode || 500, { error: err.message || "Server error" });
  }
};
