
const { json, requireUser, isAdminEmail, airtableConfig, airtableFetch, clampRecords } = require("./_common");

exports.handler = async (event, context) => {
  try{
    const u = requireUser(context);
    const { baseId, tableName } = airtableConfig();

    const url = `/${baseId}/${encodeURIComponent(tableName)}?pageSize=50&sort[0][field]=Received At&sort[0][direction]=desc`;
    const res = await airtableFetch(url, { method:"GET" });
    const data = await res.json();
    if(!res.ok){
      return json(res.status, { error: data?.error?.message || "Airtable error" });
    }
    const isAdmin = isAdminEmail(u.email);
    return json(200, { records: clampRecords(data.records, 50), isAdmin });
  }catch(err){
    return json(err.statusCode || 500, { error: err.message || "Server error" });
  }
};
