
const { json, requireUser, isAdminEmail, airtableConfig, airtableFetch } = require("./_common");

exports.handler = async (event, context) => {
  try{
    const u = requireUser(context);
    if(!isAdminEmail(u.email)) return json(403, { error: "Admin only" });

    const body = JSON.parse(event.body || "{}");
    const id = body.id;
    if(!id) return json(400, { error: "Missing record id" });

    const { baseId, tableName } = airtableConfig();
    const delRes = await airtableFetch(`/${baseId}/${encodeURIComponent(tableName)}/${id}`, { method:"DELETE" });
    const delData = await delRes.json();
    if(!delRes.ok){
      return json(delRes.status, { error: delData?.error?.message || "Airtable delete failed" });
    }
    return json(200, { ok:true });
  }catch(err){
    return json(err.statusCode || 500, { error: err.message || "Server error" });
  }
};
