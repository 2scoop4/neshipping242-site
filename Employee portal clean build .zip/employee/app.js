
const $ = (s) => document.querySelector(s);
const loginView = $("#loginView");
const appView = $("#appView");
const loginForm = $("#loginForm");
const loginError = $("#loginError");
const forgotLink = $("#forgotLink");
const helloText = $("#helloText");
const roleLabel = $("#roleLabel");
const envHint = $("#envHint");

const pkgTbody = $("#pkgTbody");
const searchInput = $("#searchInput");
const filterIsland = $("#filterIsland");
const filterStatus = $("#filterStatus");
const addBtn = $("#addBtn");
const refreshBtn = $("#refreshBtn");

const modalBackdrop = $("#modalBackdrop");
const modalClose = $("#modalClose");
const modalTitle = $("#modalTitle");
const pkgForm = $("#pkgForm");
const formError = $("#formError");

let user = null;
let isAdmin = false;
let packages = [];
let editingId = null;

function show(el){ el.classList.remove("hidden"); }
function hide(el){ el.classList.add("hidden"); }
function setError(el, msg){
  if(!msg){ hide(el); el.textContent=""; return; }
  el.textContent = msg;
  show(el);
}

function ensureIdentity(){
  if(!window.netlifyIdentity){
    setError(loginError, "Netlify Identity failed to load. Check network or blockers and refresh.");
    return false;
  }
  return true;
}

function getToken(){
  // netlifyIdentity.currentUser() returns user with token accessor
  const u = window.netlifyIdentity.currentUser();
  if(!u) return null;
  return u.token && (u.token.access_token || (typeof u.token === "function" ? null : null));
}

async function getAccessToken(){
  const u = window.netlifyIdentity.currentUser();
  if(!u) return null;
  try{
    const t = await u.jwt(true);
    return t;
  }catch(e){
    return null;
  }
}

async function api(path, opts={}){
  const token = await getAccessToken();
  const headers = Object.assign({}, opts.headers || {});
  if(token) headers["Authorization"] = `Bearer ${token}`;
  headers["Content-Type"] = headers["Content-Type"] || "application/json";
  const res = await fetch(path, {...opts, headers});
  const text = await res.text();
  let data = null;
  try{ data = text ? JSON.parse(text) : null; }catch(e){ data = {raw:text}; }
  if(!res.ok){
    const msg = (data && (data.error || data.message)) ? (data.error || data.message) : `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return data;
}

function formatDate(s){
  if(!s) return "";
  try{
    const d = new Date(s);
    return d.toLocaleString();
  }catch(e){
    return s;
  }
}

function photoCell(photoArr){
  if(!photoArr || !photoArr.length) return "";
  const url = photoArr[0].thumbnails?.small?.url || photoArr[0].url;
  return `<a href="${photoArr[0].url}" target="_blank" rel="noopener"><img class="thumb" src="${url}" alt="photo"/></a>`;
}

function rowHtml(p){
  const f = p.fields || {};
  return `
    <tr data-id="${p.id}" class="pkg-row">
      <td class="small">+</td>
      <td>${escapeHtml(f["Tracking Number"]||"")}</td>
      <td>${escapeHtml(f["Customer Name"]||"")}</td>
      <td>${escapeHtml(f["Island"]||"")}</td>
      <td><span class="badge">${escapeHtml(f["Status"]||"Received")}</span></td>
      <td>${escapeHtml(f["Carrier"]||"")}</td>
      <td>${escapeHtml(f["Package Type"]||"")}</td>
      <td>${escapeHtml((f["Weight (lb)"] ?? "")+"")}</td>
      <td>${escapeHtml(f["Supplier"]||"")}</td>
      <td>${photoCell(f["Package Photo"])}</td>
      <td class="small">${escapeHtml(formatDate(f["Received At"]))}</td>
      <td class="row-actions">
        <button title="Edit" data-action="edit">✏️</button>
        <button title="Delete" data-action="delete" class="danger" ${isAdmin ? "" : "disabled"}>🗑️</button>
      </td>
    </tr>
    <tr data-expand="${p.id}" class="hidden">
      <td colspan="12">
        <div style="padding:10px 2px;">
          <div class="small"><b>Description:</b> ${escapeHtml(f["Item Description"]||"")}</div>
          <div class="small" style="margin-top:6px;"><b>Received by:</b> ${escapeHtml(f["Received By"]||"")}</div>
        </div>
      </td>
    </tr>
  `;
}

function escapeHtml(str){
  return String(str).replace(/[&<>"']/g, (m)=>({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;" }[m]));
}

function render(){
  const q = (searchInput.value || "").trim().toLowerCase();
  const isl = filterIsland.value;
  const st = filterStatus.value;

  const filtered = packages.filter(p=>{
    const f = p.fields || {};
    if(isl && (f["Island"]||"") !== isl) return false;
    if(st && (f["Status"]||"") !== st) return false;
    if(!q) return true;
    const hay = [
      f["Tracking Number"], f["Customer Name"], f["Supplier"], f["Carrier"],
      f["Item Description"], f["Package Type"], f["Island"], f["Status"]
    ].join(" ").toLowerCase();
    return hay.includes(q);
  });

  pkgTbody.innerHTML = filtered.map(rowHtml).join("");
}

async function loadPackages(){
  envHint.textContent = "Loading…";
  const data = await api("/.netlify/functions/getPackages", { method:"GET" });
  packages = data.records || [];
  isAdmin = !!data.isAdmin;
  roleLabel.textContent = isAdmin ? "Admin" : "Employee";
  envHint.textContent = `Records: ${packages.length}`;
  render();
}

function openModal(mode, record){
  editingId = record?.id || null;
  modalTitle.textContent = mode === "edit" ? "Edit package" : "Add package";
  setError(formError, "");
  pkgForm.reset();
  const f = record?.fields || {};
  pkgForm.tracking.value = f["Tracking Number"] || "";
  pkgForm.customer.value = f["Customer Name"] || "";
  pkgForm.island.value = f["Island"] || "";
  pkgForm.status.value = f["Status"] || "Received";
  pkgForm.carrier.value = f["Carrier"] || "";
  pkgForm.ptype.value = f["Package Type"] || "Box";
  pkgForm.weight.value = f["Weight (lb)"] ?? "";
  pkgForm.supplier.value = f["Supplier"] || "";
  pkgForm.desc.value = f["Item Description"] || "";
  show(modalBackdrop);
}

function closeModal(){
  hide(modalBackdrop);
  editingId = null;
}

async function fileToBase64(file){
  if(!file) return null;
  return await new Promise((resolve, reject)=>{
    const reader = new FileReader();
    reader.onload = ()=> resolve(reader.result);
    reader.onerror = ()=> reject(reader.error);
    reader.readAsDataURL(file);
  });
}

async function submitForm(e){
  e.preventDefault();
  setError(formError, "");
  const btn = $("#saveBtn");
  btn.disabled = true;
  btn.textContent = "Saving…";
  try{
    const photoFile = pkgForm.photo.files && pkgForm.photo.files[0];
    const photoDataUrl = photoFile ? await fileToBase64(photoFile) : null;

    const payload = {
      id: editingId,
      fields: {
        "Tracking Number": pkgForm.tracking.value.trim(),
        "Customer Name": pkgForm.customer.value.trim(),
        "Island": pkgForm.island.value,
        "Status": pkgForm.status.value,
        "Carrier": pkgForm.carrier.value.trim(),
        "Package Type": pkgForm.ptype.value,
        "Weight (lb)": Number(pkgForm.weight.value),
        "Supplier": pkgForm.supplier.value.trim(),
        "Item Description": pkgForm.desc.value.trim(),
      },
      photo: photoDataUrl ? {
        dataUrl: photoDataUrl,
        filename: photoFile.name || "photo.jpg",
        contentType: photoFile.type || "image/jpeg"
      } : null
    };

    if(editingId){
      await api("/.netlify/functions/updatePackage", { method:"POST", body: JSON.stringify(payload) });
    }else{
      await api("/.netlify/functions/submitPackage", { method:"POST", body: JSON.stringify(payload) });
    }
    closeModal();
    await loadPackages();
  }catch(err){
    setError(formError, err.message || "Failed to save.");
  }finally{
    btn.disabled = false;
    btn.textContent = "Save";
  }
}

async function doLogin(e){
  e.preventDefault();
  setError(loginError, "");
  if(!ensureIdentity()) return;

  const email = $("#email").value.trim();
  const password = $("#password").value;
  const btn = loginForm.querySelector("button");
  btn.disabled = true; btn.textContent = "Signing in…";
  try{
    // Use GoTrue directly for custom login
    const goTrue = window.netlifyIdentity.gotrue;
    if(!goTrue) throw new Error("Identity client not ready. Refresh and try again.");
    await goTrue.login(email, password, true);
    // refresh currentUser
    window.netlifyIdentity.refresh().then(()=>{});
  }catch(err){
    setError(loginError, err.message || "Login failed.");
  }finally{
    btn.disabled = false; btn.textContent = "Continue";
  }
}

async function requestPassword(){
  setError(loginError, "");
  if(!ensureIdentity()) return;
  const email = $("#email").value.trim();
  if(!email){
    setError(loginError, "Enter your email first.");
    return;
  }
  try{
    const goTrue = window.netlifyIdentity.gotrue;
    await goTrue.requestPasswordRecovery(email);
    setError(loginError, "Password recovery email sent (check inbox/spam).");
  }catch(err){
    setError(loginError, err.message || "Could not send recovery email.");
  }
}

function showApp(u){
  user = u;
  helloText.textContent = `Hello, ${u?.email || "Employee"}`;
  hide(loginView);
  show(appView);
  loadPackages().catch(e=> setError(loginError, e.message));
}

function showLogin(){
  user = null;
  show(loginView);
  hide(appView);
}

function wire(){
  loginForm.addEventListener("submit", doLogin);
  forgotLink.addEventListener("click", (e)=>{ e.preventDefault(); requestPassword(); });

  addBtn.addEventListener("click", ()=> openModal("add", null));
  refreshBtn.addEventListener("click", ()=> loadPackages().catch(console.error));
  modalClose.addEventListener("click", closeModal);
  modalBackdrop.addEventListener("click", (e)=>{ if(e.target === modalBackdrop) closeModal(); });
  pkgForm.addEventListener("submit", submitForm);

  searchInput.addEventListener("input", render);
  filterIsland.addEventListener("change", render);
  filterStatus.addEventListener("change", render);

  $("#logoutBtn").addEventListener("click", (e)=>{
    e.preventDefault();
    window.netlifyIdentity.logout();
  });

  pkgTbody.addEventListener("click", async (e)=>{
    const tr = e.target.closest("tr");
    if(!tr) return;
    const id = tr.getAttribute("data-id");
    const action = e.target.getAttribute("data-action");

    if(action === "edit" && id){
      const rec = packages.find(r=>r.id===id);
      openModal("edit", rec);
      return;
    }
    if(action === "delete" && id){
      if(!isAdmin) return;
      if(!confirm("Delete this package record?")) return;
      try{
        await api("/.netlify/functions/deletePackage", { method:"POST", body: JSON.stringify({id}) });
        await loadPackages();
      }catch(err){
        alert(err.message || "Delete failed.");
      }
      return;
    }

    // expand row
    if(id){
      const exp = document.querySelector(`tr[data-expand="${id}"]`);
      if(exp) exp.classList.toggle("hidden");
    }
  });
}

function boot(){
  if(!ensureIdentity()) return;

  window.netlifyIdentity.on("init", (u)=>{
    if(u) showApp(u);
    else showLogin();
  });
  window.netlifyIdentity.on("login", (u)=>{
    showApp(u);
  });
  window.netlifyIdentity.on("logout", ()=>{
    showLogin();
  });
  // init
  window.netlifyIdentity.init();
}

wire();
boot();
